﻿using System;
using dbServer;


public class serv
{


    public static void Main()
    {
        Server server = new Server();
        server.startAServerThread();
        //GetIP.getUserNetworkType();
    }




}